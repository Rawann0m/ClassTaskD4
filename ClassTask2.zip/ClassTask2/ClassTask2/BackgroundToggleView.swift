//
//  BackgroundToggleView.swift
//  ClassTask2
//
//  Created by Rawan on 06/09/1446 AH.
//
import SwiftUI
// Use @Binding to pass data between views.
struct BackgroundToggleView: View {
    @Binding var toggle: Bool
    
    var body: some View {
        Toggle(isOn: $toggle) {
            Text("Change Background")
                .foregroundColor(.white)
        }
        .padding()
    }
}
