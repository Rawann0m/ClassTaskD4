//
//  ClassTask2App.swift
//  ClassTask2
//
//  Created by Rawan on 06/09/1446 AH.
//

import SwiftUI

@main
struct ClassTask2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
