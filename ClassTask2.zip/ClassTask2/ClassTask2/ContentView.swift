//
//  ContentView.swift
//  ClassTask2
//
//  Created by Rawan on 06/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var name: String = ""
    @State private var displayName: String = "Your name"
    @State private var toggle = false
    var body: some View {
        ZStack {
            // Background layer
            ( toggle ?  Color.blue.opacity(0.5) : Color.purple.opacity(0.5))
                .edgesIgnoringSafeArea(.all)
            //vstack used to show the textfield and the button and the name display and the toggle underneath each other
            VStack {
                TextField("Enter your name", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                //button
                Button(action: {
                    displayName = "Hello, \(name)!"
                }) {
                    Text("Submit")
                        .padding()
                        .frame(width: 150)
                        .background(Color.white)
                        .foregroundColor(.purple)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                //here the name of the user will be displayed after clicking the button
                Text(displayName)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                //binding to dispalay the toggle that will change the color to blue and back to purple
                BackgroundToggleView(toggle: $toggle)
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
