//
//  ContentView.swift
//  ClassTask
//
//  Created by Roona Star on 06/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            // Background layer
            Color.purple.opacity(0.3)
                .edgesIgnoringSafeArea(.all)
            VStack {
                
                HStack {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.white)
                        .padding()
                        .cornerRadius(10)
                        .shadow(radius: 10)
                    Text("User Name ")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding()
                    
                }
                Button(action: {
                    print("Button tapped!")
                }) {
                    Text("Click here ")
                        .padding()
                        .frame(width: 200)
                        .background(Color.white)
                        .foregroundColor(.purple)
                        .cornerRadius(10)
                    
                }
            }
            
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
