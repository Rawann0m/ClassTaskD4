//
//  ClassTaskApp.swift
//  ClassTask
//
//  Created by Roona Star on 06/09/1446 AH.
//

import SwiftUI

@main
struct ClassTaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
